#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include "myshell.h"
#include <fcntl.h>
#include <ctype.h>
#include<signal.h>

static char *defaultPrompt = "hello:";
static char *prompt;
struct kv vars[1024] = {0};
char *history[NUM_HISTORY] = {NULL};
int iHistoryIdx = 0;

void initVars(){
    for(int i= 0; i < sizeof(vars) / sizeof(struct kv); i++){
        memset(&vars[i], '\0', sizeof(struct kv));
        vars[i].free = 1;
    }
}

void removeCurrentCommand(){
    if(history[iHistoryIdx] != NULL){
        free(history[iHistoryIdx]);
    }
    iHistoryIdx = (iHistoryIdx -1) % NUM_HISTORY;
}

char * saveCmd(char * cmd){
    if(!strcmp(cmd, CMD_REPEAT)){
        return NULL;
    }

    iHistoryIdx = (iHistoryIdx + 1) % NUM_HISTORY;

    if(history[iHistoryIdx] == NULL){
        history[iHistoryIdx] = (char *)malloc(DEFAULT_BUFFER_INPUT_CHAR);
    }
    memset(history[iHistoryIdx], '\0', DEFAULT_BUFFER_INPUT_CHAR);
    strncpy(history[iHistoryIdx], cmd, DEFAULT_BUFFER_INPUT_CHAR);

    return history[iHistoryIdx];
}


struct kv * get_by_key(char *k){
    for(int i= 0; i < sizeof(vars) / sizeof(struct kv); i++){
        if(!strcmp(k, vars[i].k) && !vars[i].free){
            return &vars[i];
        }
    }
    return NULL;
}

struct kv * set_by_key(char *k, char *v){
    for(int i= 0; i < sizeof(vars) / sizeof(struct kv); i++){
        if(vars[i].free){
            strncpy(vars[i].k, k, sizeof(vars[i].k) / sizeof(char));
            strncpy(vars[i].v, v, sizeof(vars[i].v) / sizeof(char));
            vars[i].free = 0;
            return &vars[i];
        }
    }
    return NULL;
}

struct kv * del_by_key(char *k){
    for(int i= 0; i < sizeof(vars) / sizeof(struct kv); i++){
        if(!strcmp(k, vars[i].k)){
            vars[i].free = 1;
            return &vars[i];
        }
    }
    return NULL;
}

int cleanup_socket() {
    return 0;
}


void cleanup() {
}

void exit_error() {
    cleanup();
    exit(RC_ERR);
}

void exit_ok() {
    cleanup();
    exit(RC_OK);
}

void print_prompt() {
    char curDir[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char *cpDirRes = getcwd(curDir, DEFAULT_BUFFER_INPUT_CHAR);

    if (cpDirRes == NULL) {
        perror("Could not read dir.");
        exit_error();
    }

    printf("%s ", prompt);
}

// It is a POSIX wrapper function to a syscall func with the same name.
void handler_cd(char *cpExtra, unsigned long iExtraLen) {
    char cDir[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char cpFormat[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};

    sprintf(cpFormat, "%%%lus", iExtraLen - 1);
    int iReadRes = sscanf(cpExtra, cpFormat, cDir);

    if (iReadRes != 1) {
        set_last_exit_code(-1);
        perror("Could not read dir");
        return;
    }

    int iRes = chdir(cDir);
    if (iRes != 0) {
        set_last_exit_code(-1);
        perror("Could not chdir");
    }
}

void handler_echo(char *cpExtra, int iExtraLen) {
    set_last_exit_code(0);
    printf("%s", cpExtra);
}

void handler_prompt(char *cpExtra, int iExtraLen) {
    if (strstr(cpExtra, "= ") != NULL) {
        char *found = strstr(cpExtra, "= ");

        if (prompt == defaultPrompt) {
            prompt = (char *) malloc(DEFAULT_PROMPT_BUFFER);
        }

        strncpy(prompt, found + 2, DEFAULT_PROMPT_BUFFER - 1);
    }

    set_last_exit_code(0);
}

void handler_read(char *cpExtra, int iExtraLen) {
    char varIn[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char *cpReadRes = fgets(varIn, sizeof(varIn) - 1, stdin);
    if (cpReadRes == NULL) { return; }
    char *value = strtok(varIn, "\n");
//    printf("putting %s with %s", cpExtra, value);
    set_by_key(cpExtra, value);
}

void handler_var_assign(char *cpCmd, char* cpExtra) {
    if (strstr(cpExtra, " = ") != NULL) {
        return;
    }

    char *pKey = strtok(cpCmd, "$");
    char *pVal = strtok(cpExtra, "= ");
    set_by_key(pKey, pVal);
}

void str_replace(char *target, const char *needle, const char *replacement)
{
    char buffer[DEFAULT_BUFFER_INPUT_CHAR] = { 0 };
    char *insert_point = &buffer[0];
    const char *tmp = target;
    size_t needle_len = strlen(needle);
    size_t repl_len = strlen(replacement);

    while (1) {
        const char *p = strstr(tmp, needle);

        // walked past last occurrence of needle; copy remaining part
        if (p == NULL) {
            strcpy(insert_point, tmp);
            break;
        }

        // copy part before needle
        memcpy(insert_point, tmp, p - tmp);
        insert_point += p - tmp;

        // copy replacement string
        memcpy(insert_point, replacement, repl_len);
        insert_point += repl_len;

        // adjust pointers, move on
        tmp = p + needle_len;
    }

    // write altered string back to target
    strcpy(target, buffer);
}

void replace_vars_in_cmd(char *target){
    for(int i= 0; i < sizeof(vars) / sizeof(struct kv); i++){
        if(!vars[i].free){
            char buff[DEFAULT_BUFFER_INPUT_CHAR] = { 0 };
            sprintf(buff, "$%s", vars[i].k);
            str_replace(target, buff, vars[i].v);
//            printf("replaceing %s with %s", buff, vars[i].v);
        }
    }
}
// system is a library function, uses fork behind the scenes.
int handler_system(char *cpCmd, char *cpExtra, int background) {

    int i = 1;
    char *p = strtok(cpExtra, " ");
    char *args[2048] = {NULL};
    args[0] = cpCmd;

    while (p != NULL && i < sizeof(args)) {
        args[i++] = p;
        if (p != cpExtra) {
            *(--p) = '\0';
        }
        p = strtok(NULL, " ");
    }

    int iForkPid = fork();
    int status;
    if (iForkPid == 0) {
        execvp(args[0], args);
        perror("Failed running the process!");
        return RC_ERR;
    } else {
        if (!background) {
            waitpid(iForkPid, &status, 0);
            return WEXITSTATUS(status);
        }
        return 0;

    }
}

char *trimwhitespace(char *str) {
    char *end;

    // Trim leading space
    while (isspace((unsigned char) *str)) str++;

    if (*str == 0)  // All spaces?
        return str;

    // Trim trailing space
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char) *end)) end--;

    // Write new null terminator character
    end[1] = '\0';

    return str;
}

void parse_commands(char **cppCommands, int cppCommandsLen, char *sep, char *cpIn) {
    int i = 0;
    char *p = strtok(cpIn, sep);

    while (p != NULL && i < cppCommandsLen - 1) {
        cppCommands[i++] = p;
        if (p != cpIn) {
            *(--p) = '\0';
        }
        p = strtok(NULL, sep);
    }
    cppCommands[i] = NULL;

//    for (int k = 0; k < i; k++) {
//        printf("%s", cppCommands[k]);
//    }
}

int handler_piped(char **args, int myStdin, int originalStdout) {
    if (*args == NULL) {
        return RC_ERR;
    }

    int fd[2];
    pipe(fd);

    int forked;
    int status = 0;
    int isLast = *(args + 1) == NULL;

    if ((forked = fork()) > 0) {
        close(fd[1]);
        if (!isLast) {
            int ret = handler_piped(++args, fd[0], originalStdout);
            close(fd[0]);
            return ret;
        } else {
            waitpid(forked, &status, 0);
            return WEXITSTATUS(status);
        }

    } else {
        int redirectedFd = -1;
        int FdIsInput = 0;
        int redirectStderr = 0;

        if (strstr(*(args) + 1, ">> ") != NULL) {
            char *found = strstr(*args, ">> ");
            if (*(found - 1) == '2') { redirectStderr = 1; }

            // terminate string correctly
            *(found - 1) = '\0';
            *(found) = '\0';
            *(found + 1) = '\0';

            trimwhitespace(*args);
            trimwhitespace(found + 2);

            if (*(found + 3) == '\0') {
                perror(ERR_REDIRECT_FILE_NOT_SPECIFIED);
                return RC_ERR;
            }
            redirectedFd = open((found + 3), O_RDWR | O_CREAT | O_APPEND, DEFAULT_REDIRECT_PERMISSIONS);
        }
        else if (strstr(*(args) + 1, "> ") != NULL) {
            char *found = strstr(*args, "> ");
            if (*(found - 1) == '2') { redirectStderr = 1; }

            *(found - 1) = '\0';
            *(found) = '\0';
            trimwhitespace(*args);
            trimwhitespace(found + 2);

            if (*(found + 2) == '\0') {
                perror(ERR_REDIRECT_FILE_NOT_SPECIFIED);
                return RC_ERR;
            }
            redirectedFd = open((found + 2), O_RDWR | O_CREAT | O_TRUNC, DEFAULT_REDIRECT_PERMISSIONS);
        }
        else if (strstr(*(args) + 1, "< ") != NULL) {
            char *found = strstr(*args, "< ");
            if (*(found - 1) == '2') { redirectStderr = 1; }

            *(found - 1) = '\0';
            *(found) = '\0';
            trimwhitespace(*args);
            trimwhitespace(found + 2);

            if (*(found + 2) == '\0') {
                perror(ERR_REDIRECT_FILE_NOT_SPECIFIED);
                return RC_ERR;
            }
            FdIsInput = 1;
            freopen((found + 2),"r",stdin);
        }


        if (redirectedFd != -1 && redirectStderr) {
            dup2(redirectedFd, STDERR_FILENO);
        }

        if(!FdIsInput){
            dup2(myStdin, STDIN_FILENO);
        }
        if (isLast) {
            close(fd[1]);
            (redirectedFd != -1 ? dup2(redirectedFd, STDOUT_FILENO) : dup2(originalStdout, STDOUT_FILENO));
        } else {
            (redirectedFd != -1 ? dup2(redirectedFd, STDOUT_FILENO) : dup2(fd[1], STDOUT_FILENO));
            close(fd[0]);
        }

        char cpReadFormat[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
        char cpCmd[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
        char cpExtra[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};

        sprintf(cpReadFormat, "%%%lus %%%luc", sizeof(cpCmd) - 1, sizeof(cpExtra) - 1);
        memset(cpCmd, 0, sizeof(cpCmd));
        memset(cpExtra, 0, sizeof(cpExtra));

        // Background handling
        int background = 0;
        if (strstr(*args, AMP) != NULL) {
            char *p = strtok(*args, AMP);
            if (p != NULL) {
                background = 1;
            }
        }

        int iExtracted = sscanf(*args, cpReadFormat, cpCmd, cpExtra);
        cpExtra[strcspn(cpExtra, "\r\n")] = '\0';

        if (iExtracted == -1) { return RC_ERR; }
        int status = handler_system(cpCmd, cpExtra, background);

        if (redirectedFd != -1) {
            close(redirectedFd);
        }

        exit(status);
    }
}

int handler_exec(char *cpIn){
    int originalStdout = dup(STDOUT_FILENO);
    int originalStdin = dup(STDIN_FILENO);

    char *args[2048] = {NULL};
    memset(args, 0, sizeof(args));
    parse_commands(args, sizeof(args), SEP_PIPE, cpIn);

    // Save last ret code
    int retCode = handler_piped(args, originalStdin, originalStdout);
    set_last_exit_code(retCode);

    dup2(originalStdin, STDIN_FILENO);
    dup2(originalStdout, STDOUT_FILENO);
    close(originalStdin);
    close(originalStdout);
    return retCode;
}


void handler_if(char *cpExtra){
    int ret = handler_exec(cpExtra);
    int shouldStartExecute = 0;

    char in[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char *cpReadRes = fgets(in, sizeof(in) - 1, stdin);
    if (cpReadRes == NULL) { return; }

    strtok(in, "\n");
    replace_vars_in_cmd(in);

    while(strcmp("fi", in)){
        if(shouldStartExecute){
            handler_exec(in);
        }

        if(!strcmp("then", in) && !ret){
            shouldStartExecute =1;
        }

        if(!strcmp("else", in) && ret){
            shouldStartExecute =1;
        }

        memset(in, '\0', DEFAULT_BUFFER_INPUT_CHAR);
        fgets(in, sizeof(in) - 1, stdin);
        strtok(in, "\n");
        replace_vars_in_cmd(in);

    }
}

void set_last_exit_code(int retCode){
    strncpy(vars[0].k, "?", sizeof(vars[0].k) / sizeof(char));
    sprintf(vars[0].v, "%d", retCode);
    vars[0].free = 0;
}

void intHandler(int dummy) {
    printf("You typed Control-C!\n");
}

int main() {
    signal(SIGINT, intHandler);

    char cpReadFormat[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char cpIn[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char cpCmd[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    char cpExtra[DEFAULT_BUFFER_INPUT_CHAR] = {'\0'};
    prompt = defaultPrompt;
    initVars();
    sprintf(cpReadFormat, "%%%lus %%%luc", sizeof(cpCmd) - 1, sizeof(cpExtra) - 1);

    int shouldReadStdin = 1;

    while (1) {
        if(shouldReadStdin){
            print_prompt();
        }

        if(shouldReadStdin){
            memset(cpIn, 0, sizeof(cpIn));
        }
        memset(cpCmd, 0, sizeof(cpCmd));
        memset(cpExtra, 0, sizeof(cpExtra));
        cpIn[strcspn(cpIn, "\r\n")] = '\0';

        if(shouldReadStdin){
            char *cpReadRes = fgets(cpIn, sizeof(cpIn) - 1, stdin);
            if (cpReadRes == NULL) { continue; }
        }
        shouldReadStdin = 1;
        saveCmd(cpIn);

        int iExtracted = sscanf(cpIn, cpReadFormat, cpCmd, cpExtra);
        cpExtra[strcspn(cpExtra, "\r\n")] = '\0';

        if (iExtracted == -1) {continue; }

        if (!strcmp(cpCmd, "quit")) {
            exit_ok();
            break;
        }
        if (cpCmd[0] == '$') {
           handler_var_assign(cpCmd, cpExtra);
           continue;
        }

        replace_vars_in_cmd(cpCmd);
        replace_vars_in_cmd(cpExtra);

        if (!strcmp(cpCmd, "!!")) {
            removeCurrentCommand();
            char * historicCmd = history[iHistoryIdx];
            strcpy(cpIn, historicCmd);
            shouldReadStdin = 0;
            continue;
        }
        else if (!strcmp(cpCmd, "if")) {
            handler_if(cpExtra);
        }else if (!strcmp(cpCmd, "read")) {
            handler_read(cpExtra, sizeof(cpExtra));
        }else if (!strcmp(cpCmd, "echo")) {
            handler_echo(cpExtra, sizeof(cpExtra));
        } else if (!strcmp(cpCmd, "cd")) {
            handler_cd(cpExtra, sizeof(cpExtra));
        } else if (!strcmp(cpCmd, "prompt")) {
            handler_prompt(cpExtra, sizeof(cpExtra));
        } else {
            handler_exec(cpIn);
        }
    }

    return 0;
}
