ID 314195041
This project implements a shell.

Note:
* Final binary name is `myshell`
* Test output is test_output.txt

Assumptions based on examples / none of:
* Syntax is very strict down to the space level.
* Redirect to file AND pipe not supported
* () not supported
* Max variables to store is 1024
* Unitialized variables show as their literal instead of empty.
* Echo is not pipeable since there was no such example. It supports variables though.
* All other cms support multi pipeline and variables.