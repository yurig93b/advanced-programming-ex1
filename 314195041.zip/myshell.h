//
// Created by Yuri Grigorian on 04/04/2022.
//

#ifndef ADV_01
#define ADV_01

#define ERR_REDIRECT_FILE_NOT_SPECIFIED "No fname specfied to redirect!"

#define SEP_PIPE "|"
#define AMP "&"
#define CMD_REPEAT "!!"

#define DEFAULT_BUFFER_INPUT_CHAR 1024
#define DEFAULT_PROMPT_BUFFER 1024
#define DEFAULT_BUFFER_KV 1024
#define NUM_HISTORY 20
#define DEFAULT_PORT 2222
#define DEFAULT_PROMPT_SEP " "
#define DEFAULT_REDIRECT_PERMISSIONS 0666
#define RC_OK 0
#define RC_ERR 1

struct kv{
    int free;
    char k[DEFAULT_BUFFER_KV];
    char v[DEFAULT_BUFFER_KV];
};

void set_last_exit_code(int retCode);
void cleanup();
int cleanup_socket();
void exit_error();
void exit_ok();
void print_prompt();
void handler_echo(char *cpExtra, int iExtraLen);
void handler_cd(char *cpExtra, unsigned long iExtraLen);
int handler_piped(char **args, int myStdin, int originalStdout);
int handler_system(char *cpCmd, char *cpExtra, int background);
void parse_commands(char **cppCommands, int cppCommandsLen, char *sep, char *cpIn);

#endif //ADV_01